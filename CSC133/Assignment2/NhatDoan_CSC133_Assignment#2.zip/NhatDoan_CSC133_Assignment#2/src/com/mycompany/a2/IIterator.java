package com.mycompany.a2;

interface IIterator {

	public boolean hasNext();
	public GameObject getNext();
	public GameObject atElement(int index);
}
