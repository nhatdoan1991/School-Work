package com.mycompany.a2;

abstract public class Fixed extends GameObject{
		

	@Override
	public String toString() {
		String thisClassString=super.toString();
		return thisClassString;
	}
	@Override
	public void setLocation(float x, float y) {	
	}
}
