package com.mycompany.a2;
interface  ISteerable {
	public void changeHeading(char inputCommand);
}
