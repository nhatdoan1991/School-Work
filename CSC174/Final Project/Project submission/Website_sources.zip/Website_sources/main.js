function openAddBookModal(){
document.getElementById('addbook-modal').style.display = 'block';
}

